# es_loader

This is a part of SIEM on Amazon ES. see `https://github.com/aws-samples/siem-on-amazon-elasticsearch`
